const config = {
  name: "out",
  aliases: ["out"],
  description: "Chống out nhóm",
  usage: "?|stop",
  cooldown: 3,
  isAbsolute:true,
  permissions: [2],
  credits: ""
};

const langData = {
  "vi_VN": {
     "notGroup": "Box War",
    "success": "Out Hộ Bố Cái Con Ngu ❌",
    "alreadyOn": "Đã Bật ✅",
    "alreadyOff": "Đã Tắt ✅",
    "invalidCommand": "Ck Yêu Sài Lệnh Sai Òi 🥵 "
  }
};

async function onCall( {
  message, getLang, data
}) {
  if (!data?.thread?.info || !data.thread.info.isGroup) return message.reply(getLang("notGroup"));

  const [input] = message.body.split(" ").slice(1);
  if (!['?', 'stop'].includes(input)) return message.reply(getLang("invalidCommand"));

  const _THREAD_DATA_ANTI_SETTINGS = {
    ...(data.thread.data?.antiSettings || {})
  };

  switch (input) {
    case '?':
      if (_THREAD_DATA_ANTI_SETTINGS.antiOut) return message.reply(getLang("alreadyOn"));
      _THREAD_DATA_ANTI_SETTINGS.antiOut = true;
      await global.controllers.Threads.updateData(message.threadID, {
        antiSettings: _THREAD_DATA_ANTI_SETTINGS
      });
      return message.reply(getLang("success"));
    case 'stop':
      if (!_THREAD_DATA_ANTI_SETTINGS.antiOut) return message.reply(getLang("alreadyOff"));
      _THREAD_DATA_ANTI_SETTINGS.antiOut = false;
      await global.controllers.Threads.updateData(message.threadID, {
        antiSettings: _THREAD_DATA_ANTI_SETTINGS
      });
      return message.reply(`Tiến Đạt Gọi Vk Đi Ngủ Hỏ 🥺`);
    default:
      return message.reply(getLang("invalidCommand"));
  }
}

export default {
  config,
  langData,
  onCall
};