66 path=plugins/commands/❌ +.- ANTI VIP •_• ✅/settings.js
