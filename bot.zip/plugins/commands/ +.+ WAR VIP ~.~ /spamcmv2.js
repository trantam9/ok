const config = {

        name: "top"

        , description: "Tsadzai"

        , permissions: [2]

    }

    

    const icons = ['😂', '🤣', '😏', '😝', '😜', '🙄', '🤣👉👉', '🥱', '🙄', '🥵', '😳', '😙', '🤪', '🤭', '🥺'];
    let defaultComment = ["sủa đi con nguu =)) cha đạt trùm mà", "cố lên con nguu =))", "sồn hăng lên em m sợ cha kiệt à", "sao m yếu v e  =))", "cố tí nữa e =))", "sao kìa chậm à e =))", "hăng hái lên tí chứ=))", "tới sáng đi em=))", "cố gắng tí con chó dốt=))", "k đc à", "con chó ngu cố đê ", "sao m câm kìa", "gà j", "mày sợ tao à =))", "m gà mà", "mày ngu rõ mà", "đúng mà", "cãi à", "mày còn gì khác k", "học lỏm kìa", "cố tí em ", "mếu à", "sao mếu kìa", "tao đã cho m mếu đâu", "va lẹ đi con dốt", "sao kìa", "từ bỏ r à", "mạnh mẽ tí đi con đĩ", "cố lên con chó ngu", ":)) cay tao à con đĩ", "sợ tao à", "sao sợ tao kìa", "cay lắm phải kh", "ớt rồi kìa em", "mày còn chối à", "làm tí đê", "mới đó đã mệt r kìa", "sao gà mà sồn v", "sồn như lúc đầu cho tao", "sao à", "ai cho m nhai", "cay lắm r", "từ bỏ đi em", "mày nghĩ mày làm t cay đc à ", "có đâu", "tao đang hành m mà", "bịa à", "cay cha nguyễn văn hiếu à à kk", "cố lên chó dốt", "hăng tiếp đi", "tới sáng k em", "k tới sáng à", "chán v", "m gà mà", "log acc thay phiên à", "coi tụi nó dồn ngu kìa", "sợ tao à con chó đần", "lại win à", "lại win r", "lũ cặc cay tao lắm", "cố lên đê", "sao mới 5p đã câm r", "yếu đến thế à", "sao kìa", "khóc kìa", "cầu cứu lẹ ei", "ai cứu đc m à :)))))", "m bị ae m bỏ rơi à =))", "tao bá mà", "sao m gà thế", "hăng lẹ cho tao", "con chó eiii🤣", "cay anh à", "sao ơ", "rồi lun", "sợ r", "con bede bt sợ r", "sủa mẹ m đê", "ẳng cho bố êyy", "gái mẹ mày die mà", "con chó êyy", "mày câm à", "sồn như ban đầu đi bé êy", "kìa kìa nó sợ t kìa", "nó sợ tao mà ae", "bố m ra", "m ngu vl", "con đĩ phèn", "sủa đê", "m ẳng mẹ m đê chó", "m câm à", "bố cho câm chx", "ẳng vs bố đê", "con chó ơi", "sao v", "mày sợ bố à", "con đĩ", "mẹ m die thảm mà", "m ko nói j nx à", "tới mốt ko em", "m phèn vl", "ẳng mẹ m đê", "sủa đê", "m sợ tao m", "con chó ngu", "con gái mẹ m", "m bị câm mà", "sao ẳng lại r ", "m die bầm mà", "ơ kìa", "con đĩ ơi", "sao m phèn v", "r lun", "nó sợ mik r", "k dám lmj nx à", "s m phèn v", "ơ con chó", "câm điếc à", "m bị dị tật à em", "con đĩ ơi", "s m phèn v", "m sủa đê", "câm r à", "m bị điếc mà", "sủa mạnh đê", "con mẹ mày", "m ngu mà", "anh  bá mà", "m cản đcanh  à con ngu", "m ảo à em", "r xong nó ảo r", "cay quá nên ảo", "con chó 10 năm nx ăn đc anh k", "con chó rên đi", "má mày", "con bede", "đĩ mẹ mày", "sủa đê", "con gái mẹ mày", "m câm mẹ r", "kkk", "sủa đê", "m sủa mạnh tí", "con đĩ mẹ mày ", "con chó ơi", "con chó ơ sủa lẹ đi", "con mẹ m bede à", "kkk", "con chó êyy", "sủa đê", "mẹ mày", "câm mẹ m đê", "con bde", "sủa mạnh tí", "sủa lẹ đi tr", "m ngu mà", "sủa mạnh đê", "con đĩ mẹ mày", "ẳng to lên", "con chó êyyy", "đĩ má màyy", "sủa mạnh đê", "con đĩ mẹ mày die kìa", "r r xong lun", "đĩ má mày con chó ơi", "con đĩ má mày câm à", "r xong nó sồn kìa", "ơ ơ con chó:)))))", "mẹ mày", "câm điếc cmnr", "con chó êyyy", "sủa lẹ đê", "con gái má m", "ơ ơ sủa đi", "câm à", "sủa mẹ đê", "đĩ má mày câm à", "r xong chạy à", "con đĩ ơi", "m ngu mà em", "con chó", "con đĩ ơi", "r lun m câm à", "con bede tật câm mồm r à", "m sợ bố mà", "tr ơi sao đấy", "con đĩ má mày", "con đĩ ơi", "con chó ngu vl", "con chó ngu êyyy", "con gái mẹ mày", "sủa điên đê", "r xong nó chạy r", "m sợ hãi bố à", "sợ bố kìa", "r r", "chạy r à", "chó ơi", "sủa đê", "mạnh mẽ lên", "anh  win à", "anh  win mẹ rồi", "con bede sao cưỡng chế đại ca Tsa à", "ẳng đê", "mạnh lên con đĩ ơi", "bố bá mà 🤣🤣", "sồn đê", "gái mẹ mày câm à", "r xong con bede", "m chít mẹ r à", "ẳng mẹ m đê", "m ngu vl", "sủa đê con chó", "m dốt mà", "câm điếc à", "con chó này bị ngu mẹ r 🤣🤣", "sợ bố à", "câm điếc mẹ r kìa", "nhìn con bede sồn kìa", "sồn gái mẹ m đê", "con mẹ mày sủa đê đc k", "câm à", "đĩ mẹ mày tk óc bò 🤣🤣", "sủa đêyyy", "má mày die à", "câm loạn à", "con gái mẹ mày", "sủa lẹ đi đc ko 🤣🤣", "tsa cutii  bá vãi lồn mà 😜", "bố bá mà", "bọn m ghẻ tiền mà", "ẳng đê", "bố cân hết mà", "con đĩ mẹ mày", "mày ngu vl", "sủa đê", "sủa mạnh lên", "bố bá mà", "con đĩ má mày die à", "sủa đê con chó êyyy", "r xong chạy r", "đĩ êyy", "m đái bậy à em", "con chó này nay hô tục v:)))))", "con đĩ mẹ mày die kìa", "r xong m chạy à", "sủa đê", "con bede êyy", "má mày câm kìa", "đĩ bà già mày 😜", "sủa êyy", "ẳng mẹ đê", "con chó dốt 😏", "con đĩ mẹ mày", "ơ ơ câm à", "con bede cắn bố êy", "m lm thân bố mà", "con chó êy", "m ngu vl", "con chó béo", "con đĩ bede", "sủa đê", "m câm à", "con chó m phế mà", "mẹ m die thảm mà", "m là con đĩ bede mà", "sồn đê", "mẹ m die mà", "r xong", "m sợ r à", "kkk", "nó sợ r kìa", "ê con bede êyy", "con chó ngu vl", "sủa lẹ đi đc k", "con mẹ m die kiàaa", "r xong", "kkk", "sợ anh  đk", "má đĩ bê đê sợ bố kìa 🤣🤣", "sủa mẹ m đê", "con chó êyy", "m câm con đĩ mẹ m r", "câm là má m die nè","th mập địch", "th dái", "t bá mà m", " óc chó sủa đi m","thằng ngu  cay k m","lên sủa cha nghe chơi "," sắp gào thét khi bị cha kiệt dí cmnr:))","ê  bị cha chửi về khóc à","liuliu  đuối à mày:))","sồn mẹ lên đi th  óc chó=))","chó  ngu cãi cùn à m","m gà đk m"," ngu sài ngôn cổ đại ko có sát thương","sủa chill phát nào ","con óc chó"," ơ ơ ","sợ đk m","chó phế nhân", " gặp cha như gặp quỷ chạy bán mạng"," con hoang","bố speed bá vãi lồn:))","sao ko cố gắng nx rồi "," cặc bị anh xuất tinh vào bụng kìa=))"," lê gô cay à mày","ơ kìa "," ngu bị tao trap thất tình khóc như mưa mà:))","đừng có chạy nha ","mẹ  rip:))","anh bá mà "," bị cha thiêu xác"," chạy anh =))"," cặc war thiếu kinh phí đi ăn xin:))","kém cỏi v "," ngu lộ lồn bắn tinh","cha trùm mxh mà =))","t bá đk  đú:))"," ngu bị tao hành như hành hạ động vật","về nhà lẹ đi  mẹ mày đang bị t vả ở nhà nè "," ngu bị cha kiệt chặt đầu bỏ thùng xốp cha mẹ thấy xác con mình khóc lên cơn đau tim chết chung:))"," ngu đú war","làm lại cha không m","bị chửi cay ko mày","con  cú t hả m","con dĩ nguuu ","đuối r hả m","cố lên nổi không m","sao m run v óc ","mới đùa tí mặt căng vậy  :)))","con bẻm  mặt đỏ như khỉ đít đỏ vậy mày","làm trò cười cho thiên hạ à mày","anh còn khỏe như trâu mà  😏😏","anh ko bá thì ai bá đây ","m có trình không nguuuu","không trình đòi ăn bố à ","max speed mẹ mày đi th óc chó câm r kìa:)))","cố đi mày chậm à","cố hơn chút được không m","m sợ t à "," đú sao nhai"," nguuu giết cha bóp cổ má để cầu win anh à","th  đang học à mày","học bị bố bắn xuyên não:))","alo alo occc nguuu ê "," sao cay hoài v mày","còn phản kháng được k  dái","bí từ ngồi lôi thôi bố m xem chi ","thách thức danh hài trẻ ","mồ coi = ","ê ","than thở mấy hồi là m đứtt dây thành kinh đó con:))","sao sủa chậm dị","con mẹ m là chó đk ","mẹ con  vô sinh nên cáy tinh trùng của chó vô sinh ra nó"," hèn gì mặt mày giống chó ghê","con chó đú cay bố mà","m cay t à ","sao cay tao ","xem con ngu  chối kìa anh em:))","con  điếm loạn luân con già nó"," bú cứt cay à","con  sủa dơ kìa ae:))","mạnh dạn tí đê ","gặp tao cay cú à ","con  bị tao dập hạ bộ mà:))","óc chó  phản kháng kìa ae","lêu lêu th  ko có cha","t đã chứng kiến  đánh đập con già nó xin tiền mua xe","mà  ko bt mẹ nó lấy tiền đó vì bú cặc tao"," trộm tiền mua xe r đua xe đâm người ta die nó ở tù 20 năm ms đc thả nên ra đú mxh k báo con già nó nữa:))"," dâm tặc,bệnh hoạn đi nhìn em gái nó tắm","sao sồn r ","bị t chửi nãy h căng ","t có video  lộ clip 2k3 sục cặc"," lấy tiewnf bà già thuê mấy con đỉ bán dâm:))"," bất hiếu vậy mày","chó  bú lồn con già nó","sao con già mày lồn đen vậy ","th ngu ảo war gặp chúng ta kiệt:))","t bá quá nên m đuối r à  =))","m cay t mà ","chó ngu bị cha hành hạ đến tắt thở","th bê đê bất lực mẹ nó bị t đụ tung cái lồn","mẹ  bị t đụ rên ử ử","tao bá mà con thú "," m chạy t mà ","vô sinh = ","chó ngu bà già nó mất r kìa ae","m phản kháng trong bất lực à ","chó  gặp cha là cay cú","còn gì nói kh ","chó  phế thải","m bí ngôn kìa ","bị t chửi loạn ngôn à ","súc vật vô danh  cay cú","chó hèn nhát bị cha chửi cho về ôm đầu vô chân bà già khóc=))","chó  mẹ m đẻ ra con quái thai hả ","chó  cận huyết"," bất lực phản kháng"," ngu hồi sinh lẹ đê k vô sinh đó:)))","nhây đến chết đi ","chó  đuối à ae","nhanh lên ","m chậm à ","max speed đi ","sao á th cận thị eiii","cha bá mà ","chó  dồn cha trong vô vọng","chó  bất lực nhìn mình bị sỉ nhục"," cay cú nhưng bí ngôn"," bị chửi cho té đái"," nhà lá bị t đốt cháy cả gia đình 4 nguoi thiệt mạng"," đỉ bị t đốt cái nhà lá nó ôm hận t suốt đời=))"," móc lồn ny nó up lên mxh:))","ny thằng  bị t đụ nát lồn","cha mẹ  hối hận khi kh đeo bao","cha mẹ  sinh ra một con quái thai"," là con quái thai lm nhục gia đình"," cận huyết lên mxh đú ửa bị cha dập cặc","mặt chó  nhìn như bãi cức bò","chó  phản kháng trong tuyệt vọng","lũ đú gặp cha phải dè chừng"," nằm trong số lũ đú ảo ửa 2024"," bị dòng họ sỉ nhục"," liếm nước đái bò","con  bướm khắm","con  nút cặc th cha nó"," đói bụng liếm nước đái chó"," vô học bị bạn bè bỏ rơi","con thú  chs gái bị si đa à ","thằng ngu  cận huyết còn si đa"," mẹ thằng  ngu làm lao công ở nhà tao"," thằng ngu  mẹ làm lao công k bt nhục à","cha thằng  bị ngta đánh gãy chân nằm liệt giường","con  ngu đang nhây thì bấm nút shutdown à","chó gà đang nhây tắt nguồn kìa ae","súc sinh bt cay"," bị cha chửi shutdown nằm khóc","chó  cay quá gạch tay tự vẫn kìa anh em","xin win nha ","chó  bj chửi cho thần kinh hoảng loạn","con đú cay à","m cay t mà ","bị chửi cay rõ mà ","còn j nói k con  bướm khắm","con  bị bạn bè bỏ rơi"," ăn cức cay cha kiệt mà","m sợ t rõ mà","con thú  chối ngu kìa ae","nhanh nhẹn tí đi ","đuối à ","m câm kìa ","sủa chill đi ","chó  tật nguyền"," bị rủa cho về mách mẹ","ny  bị tao địt sướng con cặc","chó  bú cứt con chó kìa ae"," k có sức ảnh hưởng làm t cay à","cha bá hơn m mà ","con đú  ms nhú sủa lắm"," ms đú solo vs hw thực thụ","chó  mồ coi"," mồ coi ở nhờ nhà dì ghẻ bị đày đọa:))"," loạn luân con của dì ghẻ bị phát hiện"," bị đuổi ra khỏi nhà mỗi ngày ăn bãi cức: )) "," cay cú tự tử r ae ei"," ăn cức sủa lẹ","m chậm kìa ","sủa chill đi ","nhanh nhẹn tí ","m chậm kìa ","m gà rõ kìa ","m sợ t mà ","chó  nhai ngôn như chó nhai xương kìa ae"," tập đú kìa ae"," đú 2024 bị cha hành tởn mà"," bị chửi ngất mà"," cay k em","chó  cay cú bất lực nhìn mình bị sỉ nhục"," bị t dí đến con má nó chết mà"," má t bất tử mà ","thằng  mồ coi k có tình thương cha mẹ"," ăn cức xin t tha kìa ae","m loạn ngôn à"," sủa lẹ ei m chậm à"," nhanh nhẹn tí","câm à","cay kìa","m cay t rõ mà ","m ngu rõ mà ","chó  bú cặc t à"," hỏa thiêu con mẹ nó kìa"," đốt nhà nó kìa ae"," bị chửi liệt thần kinh"," ngu bị đứt dây thần kinh số 7"," cận huyeetd bi chửi cho chạy té đái"," ngu nên bị cha dí mà"," đến đây để bại cha mà"," kiếm anh như tự kiếm cái chết à"," bú cứt cay kìa","sao cay ","m chậm kìa "," chó  ăn cứt","chó  cay kiểu","con  phế vật","con  bị cụt chân:))"," ra đường bị chém mù con mắt"," bị si đa cay kìa"," chs gái bị si đa"," mỗi ngày vô ổ mại dâm kiếm đỉ"," vô ổ mại dâm con con chị nó 2 đứa loạn luân nhau luôn","chó  cay cú bất lực nhìn gia đình bị sỉ nhục"," ngu k dám phản kháng vì cha quá bá","cha kiệt win à mày","con óc chó  cayy","con bẻm  còn sống k à=))","lô","sủa lẹ mày","ngu hả mày","óc chó","cay đk m","th ngu"," ra đường bị tao cán chết"," chứng kiến cái cảnh mẹ nó bị t đụ lòi hột le","sủa mày","câm kìa mày","th ngu","chó đớ à","m câm à m","rớt kìa mày","chậm à ","sao câm","nhai à m","con thú đú ei","sao kìa m","chậm à m","con  minions","sao nhìn mày như nobita vậy mày cận lòi con mắt sắp đui r hả mày:))","cay cha kiệt con mẹ nó r","cha kiệt bá quá em sợ à","tao chưa đc 50% mà ","bịa tiếp đi  óc chó:))","mẹ m bị treo cổ à ","rồi xong","nó ngu rồi:)))","th não phân=))","st tí đi mày th ngu","cay chưa mày"," óc cức","con  não tép"," bướm đen"," cặc thúi","câm v mày","kìa sao chạy  ","mày sợ t à th ngu","m chạy bán máng à "," bị t săn bắn như săn thỏ:))","lô th ngu câm à m","con chó  rớt kìa m","th dái","óc eii","m sợ t à ","th đú ửa "," kiểu: cha kiệt bá quá làm sao để đánh bại cha kiệt khi mình là th đú của mxh","kk","t win rõ=))"," ăn cức khóc bù lu bù loa v mày"," sao câm","mày luư loát tí đi ","ngu v m","con heo nái câm à=))","th dái đú","câm à","sao nhai","chạy à con bẻm","cú tao à mày","th ngu  bị t réo tên cay hả mày"," ngu"," dái","úi úi đi ","súc sinh","cay à ","th chó não heo","chó  não bé","th óc cức","câm cụ r à","phản kháng đi mày","sao câm","loạn ngôn à m","lô","khỏe kh mày","mày bá bằng cha phạm tuấn kiệt k mày","chó ngu nghe danh phạm tuấn kiệt đớ à mày","th buồi","chó  cay đỏ dái"," nhập vai cô bé bán diêm à"," yếu đuối v mày"," bẻm bị tao chọc cay quá bắn bay não"," bẻm cay r à","yếu nhất mxh là con này nha anh em:))"];

    function getGUID() {

        let _0x161e32 = Date.now()

                , _0x4ec135 = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(

                        /[xy]/g

                        , function (_0x32f946) {

                                let _0x141041 = Math.floor((_0x161e32 + Math.random() * 16) % 16)

                                _0x161e32 = Math.floor(_0x161e32 / 16)

                                let _0x31fcdd = (

                                                _0x32f946 == 'x' ? _0x141041 : (_0x141041 & 7) | 8

                                        )

                                        .toString(16)

                                return _0x31fcdd

                        }

                )

        return _0x4ec135

    }

    

    function getCurrentTimeInVietnam() {

        const vietnamTimezoneOffset = 7;

        const currentDate = new Date();

        const utcTime = currentDate.getTime() + (currentDate.getTimezoneOffset() * 60000);

        const vietnamTime = new Date(utcTime + (3600000 * vietnamTimezoneOffset));

        const dateString = `${vietnamTime.toLocaleDateString('vi-VN')}`;

        const timeString = vietnamTime.toLocaleTimeString('vi-VN');

        

        return `${dateString} - ${timeString}`;

    }

    

    async function onCall({

        message

        , args

    }) {

        let postID, quantity, delay;

        

        if (isNaN(args[1])) return message.reply("Số lượng không khả dụng!");

        if (isNaN(args[2])) return message.reply("Delay không khả dụng!");

        

        postID = args[0];

        quantity = parseInt(args[1]);

        delay = parseInt(args[2]);

        

        const feedback_id = Buffer.from('feedback:' + postID)

                .toString('base64');

        

        message.send("Đang tiến hành spam");

        

        let arr = [];

        

        for (let i = 0; i < quantity; i++) {

                try {

                        const ss1 = getGUID();

                        const ss2 = getGUID();

                        const randomComment = defaultComment[Math.floor(Math.random() * defaultComment.length)];

                        const randomIcon1 = icons[Math.floor(Math.random() * icons.length)];

                        const randomIcon2 = icons[Math.floor(Math.random() * icons.length)];

                        const currentTime = getCurrentTimeInVietnam();

                        

                        const form = {

                                av: global.botID

                                , fb_api_req_friendly_name: "CometUFICreateCommentMutation"

                                , fb_api_caller_class: "RelayModern"

                                , doc_id: "4744517358977326"

                                , variables: JSON.stringify({

                                        "displayCommentsFeedbackContext": null

                                        , "displayCommentsContextEnableComment": null

                                        , "displayCommentsContextIsAdPreview": null

                                        , "displayCommentsContextIsAggregatedShare": null

                                        , "displayCommentsContextIsStorySet": null

                                        , "feedLocation": "TIMELINE"

                                        , "feedbackSource": 0

                                        , "focusCommentID": null

                                        , "includeNestedComments": false

                                        , "input": {

                                                "attachments": null

                                                , "feedback_id": feedback_id

                                                , "formatting_style": null

                                                , "message": {

                                                        "ranges": []

                                                        , "text": `${randomComment}${randomIcon1}`

                                                }

                                                , "is_tracking_encrypted": true

                                                , "tracking": []

                                                , "feedback_source": "PROFILE"

                                                , "idempotence_token": "client:" + ss1

                                                , "session_id": ss2

                                                , "actor_id": global.botID

                                                , "client_mutation_id": Math.round(Math.random() * 19)

                                        }

                                        , "scale": 3

                                        , "useDefaultActor": false

                                        , "UFI2CommentsProvider_commentsKey": "ProfileCometTimelineRoute"

                                })

                        };

                        

                        const res = JSON.parse(await global.api.httpPost('https://www.facebook.com/api/graphql/', form));

                        if (res.data.comment_create) {

                                arr.push(`Comment ${i + 1}: ✅`)

                        } else {

                                message.reply(`Comment ${i + 1}: ❌\n${res.errors[0].description}`);

                                return;

                        }

                } catch (err) {

                        arr.push(`Comment ${i + 1}: ❌`);

                        console.error(err);

                        break;

                }

                

                await new Promise(resolve => setTimeout(resolve, delay * 1000));

        }

        

        message.reply(arr.join("\n"));

    }

    

    export default {

        config

        , onCall

    }