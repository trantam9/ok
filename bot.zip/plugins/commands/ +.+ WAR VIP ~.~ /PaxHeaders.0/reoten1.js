64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/reoten1.js
