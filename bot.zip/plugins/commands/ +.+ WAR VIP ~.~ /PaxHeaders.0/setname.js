64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/setname.js
