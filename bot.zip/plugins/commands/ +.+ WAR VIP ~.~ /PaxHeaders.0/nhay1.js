62 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/nhay1.js
