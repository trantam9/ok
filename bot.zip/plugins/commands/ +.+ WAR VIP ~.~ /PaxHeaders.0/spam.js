61 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/spam.js
