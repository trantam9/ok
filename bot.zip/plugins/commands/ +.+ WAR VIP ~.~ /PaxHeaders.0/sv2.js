63 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/sớv2.js
