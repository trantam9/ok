64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/spamimg.js
