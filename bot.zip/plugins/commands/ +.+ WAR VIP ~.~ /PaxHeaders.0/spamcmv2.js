65 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/spamcmv2.js
