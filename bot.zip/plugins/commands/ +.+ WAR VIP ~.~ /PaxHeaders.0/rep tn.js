65 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/rep tên.js
