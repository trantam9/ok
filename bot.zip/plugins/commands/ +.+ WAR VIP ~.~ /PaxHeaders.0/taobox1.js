64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/taobox1.js
