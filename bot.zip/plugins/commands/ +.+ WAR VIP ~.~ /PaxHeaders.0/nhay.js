61 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/nhay.js
