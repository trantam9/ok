63 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/tagall.js
