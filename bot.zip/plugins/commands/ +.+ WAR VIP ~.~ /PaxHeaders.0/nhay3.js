62 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/nhay3.js
