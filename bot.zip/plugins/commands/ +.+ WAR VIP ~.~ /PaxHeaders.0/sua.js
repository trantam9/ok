60 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/sua.js
