62 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/nhay2.js
