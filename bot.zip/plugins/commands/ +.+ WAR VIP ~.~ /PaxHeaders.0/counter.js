64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/counter.js
