61 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/copy.js
