64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/motchu1.js
