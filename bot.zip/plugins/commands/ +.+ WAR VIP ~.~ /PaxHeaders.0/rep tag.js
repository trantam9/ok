64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/rep tag.js
