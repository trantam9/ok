64 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/codelag.js
