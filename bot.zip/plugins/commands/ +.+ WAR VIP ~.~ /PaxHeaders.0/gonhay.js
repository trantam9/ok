63 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/gonhay.js
