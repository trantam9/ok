60 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/kit.js
