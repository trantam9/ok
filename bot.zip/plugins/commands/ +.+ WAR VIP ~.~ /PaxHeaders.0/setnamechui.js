68 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/setnamechui.js
