61 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/kill.js
