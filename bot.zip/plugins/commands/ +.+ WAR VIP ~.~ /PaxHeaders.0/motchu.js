63 path=plugins/commands/☠️ +.+ WAR VIP ~.~ 💀/motchu.js
