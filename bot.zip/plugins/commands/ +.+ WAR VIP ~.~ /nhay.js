const config = {
  "name": "n1",
  "aliases": ["lô😜"],
  "description": "",
  "usage": "",
  "cooldown": 3,
  "permissions": [2],
  "credits": "tkin",
  "extra": {}
};

const list = [
  "rr ",
"sủa đe ",
"m sợ bố mà ",
"👎😜😜😜 ",
"mẹ mày bị bố rip mà ",
"con chó ê ",
"🤣🤣🤣 ",
"m sợ bố mà ",
"tiếp đê ",
"🤣👎 ",
"bố thấy m phế vl mà ",
"con chó ei ",
"😜😜 ",
"mày sped lên đê ",
"slow à ",
"😜😜 ",
"cấm m ngưng nha ",
" ",
"bố win à ",
"😜 ",
"mẹ mày bị bố sát hại mà:)))) ",
"alo à ",
" ",
"sủa đi à:))) ",
"alo ",
" ",
"bật bot lên đi ",
"m win đc bố k ",
"alo ",
"cay bố à ",
"sợ bố à ",
"sao mày chậm thế con nguuu ",
"😜😜😜 ",
"tiếp đê:)))) ",
"mẹ mày bị bố rip mà:))) ",
"😜😜👎 ",
"mẹ mày là búp bê tình dục của tao à=))) ",
"🤣🤣 ",
"mày thèm cứt tao à =)))) ",
"😜👎 ",
"mày bot à ",
"bố gõ tay sped nhanh hơn tốc độ bố xuất tinh vào lồn mẹ mày mà😜👎 ", 
"bị tao chửi cú mẹ r ",
"😜😜😜👎 ",
"alo ",
"sủa đê😜 ",
"😜 ",
"hoảng à=))) ",
"=)) ",
"bố xóa đói giảm nghèo cho mày mà ",
"mày định học theo tao nhây à:)) ",
"lô:))) ",
"m chạy đi chết à em=)) ",
"m chạy bố mà ",
"log acc lộ kìa culi ",
"bố nhây sát thương vcl nên mày khóc à ",
"m sủa lên ",
"t win à ",
"t win mà:)) ",
"m win j:)))) ",
"m bại mà ",
"tới chết đê ",
"k dám tới chết à:)) ",
"😜👎 ",
"bố mạnh vcl à ",
"học theo bố nhây à=)) ",
"😜👎 ",
"m câm = bố win mà ",
"mày bị bố chặt cu à ",
"bố gõ nhanh vcl ",
"bố sped chết mẹ m mà ",
"chậm j ",
"m chậm mà bố nhanh vcl ",
"nó chậm lại r kìa:)) ",
"mỏi tay à ",
"mỏi kìa ",
"m nhây có lại bố đâu ",
"con culi này cố win bố à=))) ",
" ",
"cố win bố đê ",
"cố lên sắp win mẹ r ",
"win bố đê ",
"bố win à ",
"bố có full noti 1 abum m chạy bố mà ",
"bố win à bố mạnh vcl😜😜😜👎",
"m ngu mà ",
"😜😜😜👎 ",
"con già m bị bố giết mà ",
"😜👈 ",
"bố trùm mà ",
"m ăn k nổi bố mà ",
"mẹ mày bị bố rip à ",
"con chó ghẻ =)))",
"tiếp đê con óc cặc ",
"bố spedaf=)) ",
"m chậm mà ",
"bố nhanh mà ",
"m j t j tnh nhai=))) ",
"m nhai mà:))) ",
"bố win mà ",
"cãi à🤣 ",
"cãi j ",
"m mà ",
"t đâu ",
"🤣🤣🤣",

];

let index = 0;
let isStopped = false;

export function onCall({ message }) {
  const args = message.body.split(" ").slice(1); 
  if (args[0] === "stop") {
    isStopped = true; 
    message.send(" Tiến Đạt Gọi Đi Ngủ Òi ");
    return;
  }

  if (isStopped) {
    isStopped = false;
  }

  const sendText = () => {
    message.send(list[index]);
    index = (index + 1) % list.length;
    if (!isStopped) {
      setTimeout(sendText, 6900); 
    }
  };
  sendText();
}

export default {
  config,
  onCall
};