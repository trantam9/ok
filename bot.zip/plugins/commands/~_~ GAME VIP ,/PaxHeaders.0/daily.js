64 path=plugins/commands/♠️~_~ GAME VIP •,•❌/daily.js
