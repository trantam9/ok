64 path=plugins/commands/♠️~_~ GAME VIP •,•❌/sicbo.js
