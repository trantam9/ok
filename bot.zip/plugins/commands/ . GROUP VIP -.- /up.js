const config = {
  name: "ntd",
  aliases: ["ntd"],
  credits: "XaviaTeam",
};

async function onCall({ message }) {
  const uptimeInSeconds = process.uptime();
  const hours = Math.floor(uptimeInSeconds / 3600);
  const minutes = Math.floor((uptimeInSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeInSeconds % 60);
  const time = Math.floor(uptimeInSeconds % 9999999999999999);

  try {
    const replyMessage = await message.reply(`🌸🌸🌸🌸🌸🌸🌸🌸🌸🌸
🌸 Bot : Tiến Đạt ( Real ) 裏.
▱▱▱▱▱▱▱▱▱▱▱▱▱	
*~• Time : ${hours} : ${minutes} : ${seconds} Love •~*
▱▱▱▱▱▱▱▱▱▱▱▱▱
*~• Tiến Đạt ❤️ Never Die •~*
 🌸 •-• SPAM VIP *-* 🌸
 🌸 •-• REPLY VIP *-* 🌸
 🌸 •-• REOTEN VIP *-* 🌸
 🌸 •-• SNB VIP *-* 🌸
 🌸 •-• ABD VIP *-* 🌸
▱▱▱▱▱▱▱▱▱▱▱▱▱
🌸 ADMIN SUPPORT 🌸
🌸 𝐂𝐨𝐩𝐲𝐫𝐢𝐠𝐡𝐭 𝗕𝘆 : Tiến Đạt 冷
🌸 Email:datzk25@gmail.Com
🌸 FB: facebook.com/datzk28
🌸 TIME RUN : ${time} S 🌸
▱▱▱▱▱▱▱▱▱▱▱▱▱

🌸 VPS NO  NEVER DIE 🌸
🌸🌸🌸🌸🌸🌸🌸🌸🌸🌸`);
    console.log(replyMessage);
  } catch (error) {
    console.error(error);
  }
}

export default {
  config,
  onCall,
};
