70 path=plugins/commands/🧧 •.• GROUP VIP -.- 😈/locmemdie.js
