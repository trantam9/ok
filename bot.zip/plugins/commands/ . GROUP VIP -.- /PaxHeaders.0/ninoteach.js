70 path=plugins/commands/🧧 •.• GROUP VIP -.- 😈/ninoteach.js
