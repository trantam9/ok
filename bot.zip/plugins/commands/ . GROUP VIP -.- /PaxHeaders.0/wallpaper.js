70 path=plugins/commands/🧧 •.• GROUP VIP -.- 😈/wallpaper.js
