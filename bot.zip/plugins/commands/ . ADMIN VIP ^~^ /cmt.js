﻿const config = {
    name: "spamcmt",
    descripttion: "uwu",
    permissions: [2]
}

const icons = ['❤', '🧡', '💛', '💙', '💜', '🤎', '🖤', '🤍', '💔', '❣', '💕', '💞', '💓', '💗', '💖', '💘', '💝'];

function getGUID() {
    let timestamp = Date.now();
    let uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (character) {
        let random = Math.floor((timestamp + Math.random() * 16) % 16);
        timestamp = Math.floor(timestamp / 16);
        let replacement = (character === 'x') ? random : (random & 7) | 8;
        return replacement.toString(16);
    });
    return uuid;
}

async function onCall({ message, args }) {
    if (message.type !== "message_reply") return message.reply("Hãy reply một text nào đó");
    if (message.type === "message_reply" && message.messageReply.body === '') return message.reply("Text không khả dụng")

    let postID, quantity, delay, comment;

    if (isNaN(args[1])) return message.reply("Số lượng không khả dụng!");
    if (isNaN(args[2])) return message.reply("Delay không khả dụng!");

    comment = message.messageReply.body;
    postID = args[0];
    quantity = parseInt(args[1]);
    delay = parseInt(args[2]);

    const feedback_id = Buffer.from('feedback:' + postID).toString('base64');

    message.send("Đang tiến hành spam");

    let arr = [];

    for (let i = 0; i < quantity; i++) {
        try {
            const ss1 = getGUID();
            const ss2 = getGUID();

            const form = {
                av: global.botID,
                fb_api_req_friendly_name: "CometUFICreateCommentMutation",
                fb_api_caller_class: "RelayModern",
                doc_id: "4744517358977326",
                variables: JSON.stringify({
                    "displayCommentsFeedbackContext": null,
                    "displayCommentsContextEnableComment": null,
                    "displayCommentsContextIsAdPreview": null,
                    "displayCommentsContextIsAggregatedShare": null,
                    "displayCommentsContextIsStorySet": null,
                    "feedLocation": "TIMELINE",
                    "feedbackSource": 0,
                    "focusCommentID": null,
                    "includeNestedComments": false,
                    "input": {
                        "attachments": null,
                        "feedback_id": feedback_id,
                        "formatting_style": null,
                        "message": {
                            "ranges": [],
                            "text": (comment.includes('[icon]') ? comment.replace(/\[icon]/g, `${icons[Math.floor(Math.random() * icons.length)]}${icons[Math.ceil(Math.random() * icons.length)]}`) : comment) + ' ' + icons[Math.floor(Math.random() * icons.length)]
                        },
                        "is_tracking_encrypted": true,
                        "tracking": [],
                        "feedback_source": "PROFILE",
                        "idempotence_token": "client:" + ss1,
                        "session_id": ss2,
                        "actor_id": global.botID,
                        "client_mutation_id": Math.round(Math.random() * 19)
                    },
                    "scale": 3,
                    "useDefaultActor": false,
                    "UFI2CommentsProvider_commentsKey": "ProfileCometTimelineRoute"
                })
            };
            
            const res = JSON.parse(await global.api.httpPost('https://www.facebook.com/api/graphql/', form));
            if (res.data.comment_create) {
                arr.push(`Comment ${i + 1}: ✅`)
            }
            else {
                message.reply(`Comment ${i + 1}: ❌\n${res.errors[0].description}`);
                return;
            }
        }
        catch (err) {
            arr.push(`Comment ${i + 1}: ❌`);
            console.error(err);
            break;
        }

        await new Promise(resolve => setTimeout(resolve, delay * 1000));
    }

    message.reply(arr.join("\n"));
}

export default {
    config,
    onCall
}