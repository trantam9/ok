const config = {
  "name": "info",
  "aliases": [],
  "description": "Info admin chạy bot",
  "usage": "",
  "cooldown": 3,
  "permissions": [2],
  "credits": "WaifuCat",
  "extra": {}
};

const data = `
   🐳𝐈𝐧𝐟𝐨 𝐀𝐝𝐦𝐢𝐧🐳
👀 𝐓𝐞̂𝐧: 𝑵𝒈𝒖𝒚𝒆̂̃𝒏 𝑻𝒊𝒆̂́𝒏 𝑫𝒂̣𝒕
💮 𝐁𝐢𝐞̣̂𝐭 𝐃𝐚𝐧𝐡: 𝑇𝑖𝑒̂́𝑛 𝐷𝑎̣𝑡
👤 𝐆𝐢𝐨̛́𝐢 𝐭𝐢́𝐧𝐡: 𝗡𝗮𝗺
💫 𝐂𝐡𝐢𝐞̂̀𝐮 𝐜𝐚𝐨 𝐯𝐚̀ 𝐜𝐚̂𝐧 𝐧𝐚̣̆𝐧𝐠: 𝟏𝐦62 -50kg
💘 𝐌𝐨̂́𝐢 𝐪𝐮𝐚𝐧 𝐡𝐞̣̂: Chx
🌎 𝐐𝐮𝐞̂ 𝐪𝐮𝐚́𝐧: 𝐻𝑎̀ 𝑁𝑜̣̂𝑖
👫 𝐆𝐮: ĐÉO 
🌸 𝐓𝐢́𝐧𝐡 𝐜𝐚́𝐜𝐡: 𝐍𝐡𝐚̂𝐲,𝐪𝐮𝐚̣̂𝐲 𝐧𝐡𝐮̛𝐧𝐠 𝐦𝐚̀ 𝐳𝐮𝐢 𝐭𝐢́𝐧𝐡 :>>
🌀 𝐒𝐨̛̉ 𝐭𝐡𝐢́𝐜𝐡: 𝐓𝐡𝐢́𝐜𝐡 𝐩𝐡𝐚́, 𝐚̆𝐧 𝐮𝐨̂́𝐧𝐠
☎ 𝑺𝑫𝑻: 0395988143
✉️ 𝐸𝑚𝑎𝑖𝑙 : 𝐝𝐚𝐭𝐳𝐤𝟐𝟓@𝐠𝐦𝐚𝐢𝐥.𝐜𝐨𝐦
🌐 𝑭𝒂𝒄𝒆𝒃𝒐𝒐𝒌: https://www.facebook.com/datzk25
`;

export function onCall({ message }){
 message.reply(data);
}
 export default {
    config,
    onCall
  }