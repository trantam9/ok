const config = {
    name: "tdatdz",
    aliases: ["tdatdz"],
    permissions: [2],
    isAbsolute: true
}

async function onCall({ message, getLang }) {
    await message.reply("Bắt Đi Ngủ Hoài Giận ❌");
    global.restart();
}

export default {
    config,
    onCall
}
