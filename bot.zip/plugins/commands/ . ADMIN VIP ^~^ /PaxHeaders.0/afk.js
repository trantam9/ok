66 path=plugins/commands/🌸 •.• ADMIN VIP ^~^ ❤️/afk.js
