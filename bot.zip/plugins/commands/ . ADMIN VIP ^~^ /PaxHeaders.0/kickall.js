70 path=plugins/commands/🌸 •.• ADMIN VIP ^~^ ❤️/kickall.js
