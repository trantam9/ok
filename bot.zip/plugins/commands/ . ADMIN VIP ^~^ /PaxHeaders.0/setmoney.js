71 path=plugins/commands/🌸 •.• ADMIN VIP ^~^ ❤️/setmoney.js
